package org.wanwanframework.auto.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WanwanAutoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WanwanAutoDbApplication.class, args);
	}
}
